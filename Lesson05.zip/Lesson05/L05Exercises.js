//Variables
// let fullName = "Peter Tan";
// let age = 5;

// console.log("Hi, my name is " + fullName)
// console.log("I am " + age + "years old.")

//Loops 

// for(let i=1;i<=10;i++){
//     if(i%2==1){
//         console.log(i)
//     }
// }
//Creating an array 

// const myArr = ["I Love RP!", true];

// console.log(myArr[0])
// console.log(myArr[1])


//Accessing Array Elements

const myArr = ["I Love RP!", true,5];

for (let i =0;i<myArr.length;i++){
    console.log(myArr[i])
}
